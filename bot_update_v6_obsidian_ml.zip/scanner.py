import sys
import os

# Гарантируем немедленный вывод логов на Render / Docker
os.environ["PYTHONUNBUFFERED"] = "1"
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass

import asyncio
import time
from typing import Dict, Any, List
import config
from obsidian_vault import obsidian_vault
from ml_engine import ml_engine
from binance_client import binance_client
from groq_engine import groq_engine
from tracker import portfolio

class MarketScanner:
    """
    Высокоскоростной автономный сканер рынка Binance Futures.
    Параллельно (через Semaphore) анализирует пары, отсекает мусор через Hard Gates
    и передает кандидатов (LONG и SHORT) на вердикт в Groq AI Engine.
    """
    def __init__(self):
        self.is_running = False
        self.cooldowns: Dict[str, float] = {}
        self._last_log_time = 0.0

    async def scan_market_once(self) -> List[Dict[str, Any]]:
        """Один высокоскоростной параллельный проход сканирования рынка."""
        if portfolio.is_paused:
            return []

        now = time.time()
        now_str = time.strftime("%H:%M:%S")
        portfolio.last_scan_str = now_str

        # 0. MACRO GUARD: Проверяем состояние Bitcoin (Поводырь рынка и защита от негативных новостей)
        btc_regime = await binance_client.fetch_btc_regime()
        portfolio.btc_regime_str = btc_regime.get("status_str", "")

        # 1. UNIVERSE: Получаем проверенные пары топ-30 крипторынка
        tickers = await binance_client.fetch_top_tickers(
            min_vol_usdt=config.MIN_24H_VOLUME_USDT,
            limit=config.SCAN_TICKERS_LIMIT
        )
        portfolio.funnel_stats["universe"] += len(tickers)

        # Выводим сводный лог радара раз в минуту, чтобы не забивать экран спамом
        should_log = (now - self._last_log_time) >= 60.0
        if should_log:
            self._last_log_time = now
            btc_p = btc_regime.get("pct_15m", 0.0)
            print(f"📡 [РАДАР] {now_str} — Мониторинг {len(tickers)} пар Binance | BTC: {btc_p:+.2f}% | Оценок Groq: {portfolio.funnel_stats['groq_evaluated']}", flush=True)

        sem = asyncio.Semaphore(12)  # 12 параллельных запросов для мгновенной скорости

        async def check_ticker(t: Dict[str, Any]) -> Any:
            sym = t["symbol"]

            # Строгий белый список: мгновенно отсекаем любой неизвестный токен или токен из черного списка
            if sym not in getattr(config, "TOP_CRYPTO_UNIVERSE", []) or sym in getattr(config, "EXCLUDED_TICKERS", set()):
                return None

            # Проверка кулдауна и открытых позиций
            if sym in self.cooldowns and (now - self.cooldowns[sym]) < (config.PAIR_COOLDOWN_MINUTES * 60):
                portfolio.funnel_stats["cooldown_blocked"] = portfolio.funnel_stats.get("cooldown_blocked", 0) + 1
                return None
            if sym in portfolio.open_positions:
                return None

            async with sem:
                # 2. HARD GATE: Спред в стакане
                _, _, spread = await binance_client.fetch_orderbook_spread(sym)
                if spread > config.MAX_SPREAD_PCT:
                    portfolio.funnel_stats["gate_failed"] = portfolio.funnel_stats.get("gate_failed", 0) + 1
                    return None

                # 3. HARD GATE: Анализ свечей и объема (Институциональные фильтры A+)
                analysis = await binance_client.fetch_candles_analysis(sym, interval="5m", limit=30)
                if not analysis:
                    return None

                surge = analysis["volume_surge_ratio"]
                pct_5m = analysis["pct_5m"]
                pct_15m = analysis.get("pct_15m", pct_5m)
                sl_dist = analysis["sl_pct_distance"]
                short_sl_dist = analysis.get("short_sl_dist", 0.05)
                pullback = analysis.get("pullback_from_high_pct", 0.0)
                bounce = analysis.get("bounce_from_low_pct", 0.0)
                upper_wick = analysis.get("upper_wick_pct", 0.0)
                lower_wick = analysis.get("lower_wick_pct", 0.0)
                rsi = analysis.get("rsi", 50.0)
                trend = analysis.get("trend", "CHOP")

                # Базовый институциональный фильтр кандидатов для Groq AI:
                has_vol = surge >= config.MIN_VOLUME_SURGE
                has_long_momentum = (pct_5m >= config.MIN_IMPULSE_PCT or pct_15m >= 0.40)
                has_short_momentum = (pct_5m <= -config.MIN_IMPULSE_PCT or pct_15m <= -0.40)

                is_long_cand = (has_vol or pct_15m >= 0.40) and has_long_momentum and sl_dist <= config.MAX_ALLOWED_SL_PCT and trend != "BEARISH"
                is_short_cand = config.ENABLE_SHORT and (has_vol or pct_15m <= -0.40) and has_short_momentum and short_sl_dist <= config.MAX_ALLOWED_SL_PCT and trend != "BULLISH"

                # Проверка BTC-фильтра
                if is_long_cand and btc_regime.get("is_dumping", False):
                    portfolio.funnel_stats["btc_blocked"] = portfolio.funnel_stats.get("btc_blocked", 0) + 1
                    return None
                if is_short_cand and btc_regime.get("is_pumping", False):
                    portfolio.funnel_stats["btc_blocked"] = portfolio.funnel_stats.get("btc_blocked", 0) + 1
                    return None

                is_long = is_long_cand and not btc_regime.get("is_dumping", False)
                is_short = is_short_cand and not btc_regime.get("is_pumping", False)

                if not is_long and not is_short:
                    portfolio.funnel_stats["gate_failed"] = portfolio.funnel_stats.get("gate_failed", 0) + 1
                    return None

                if is_long:
                    print(f"🔥 [КАНДИДАТ - LONG] {sym}: всплеск {surge}x, +{pct_5m:.2f}%, 15m: +{pct_15m:.2f}%, RSI {rsi:.1f}...", flush=True)
                    return {**t, **analysis, "candidate_side": "LONG", "btc_regime": btc_regime.get("status_str", "Neutral")}
                elif is_short:
                    print(f"🔻 [КАНДИДАТ - SHORT] {sym}: всплеск {surge}x, {pct_5m:.2f}%, 15m: {pct_15m:.2f}%, RSI {rsi:.1f}...", flush=True)
                    return {**t, **analysis, "candidate_side": "SHORT", "btc_regime": btc_regime.get("status_str", "Neutral")}
                return None

        tasks = [check_ticker(t) for t in tickers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        candidates_passed_hard = [r for r in results if r and isinstance(r, dict)]

        portfolio.funnel_stats["hard_gates"] += len(candidates_passed_hard)

        # 3. КВАНТОВЫЙ ML СКОРИНГ (XGBoost Alpha): расчет вероятности успеха за 0.5 мс
        for cand in candidates_passed_hard:
            ml_res = ml_engine.evaluate_candidate(cand)
            cand["ml_prob"] = ml_res.get("ml_probability", 0.5)
            cand["ml_reason"] = ml_res.get("reason", "")
            cand["ml_approved"] = ml_res.get("ml_approved", True)

        # Сортируем кандидатов по взрывному импульсу и вероятности квантовой модели
        candidates_passed_hard.sort(key=lambda x: x.get("ml_prob", 0.5) * abs(x["pct_5m"]) * x["volume_surge_ratio"], reverse=True)
        candidates_to_eval = candidates_passed_hard[:1]

        # 4. GROQ SOFT GATE (JEV AI ENGINE)
        for ctx in candidates_to_eval:
            sym = ctx["symbol"]
            cand_side = ctx.get("candidate_side", "LONG")
            portfolio.funnel_stats["groq_evaluated"] += 1
            # КУЛДАУН: ставится ТОЛЬКО монете, которая реально отправлена на оценку в Groq (без блокировки остальных!)
            self.cooldowns[sym] = now

            approved, groq_eval = await groq_engine.evaluate_setup(ctx)

            default_sl = ctx["wick_stop_loss"] if cand_side == "LONG" else ctx.get("short_wick_sl", ctx["current_price"] * 1.01)
            default_tp1 = round(ctx["current_price"] * (1.02 if cand_side == "LONG" else 0.98), 4)

            eval_entry = {
                "symbol": sym,
                "side": cand_side,
                "price": ctx["current_price"],
                "decision": groq_eval.get("decision", "SKIP"),
                "confidence": groq_eval.get("confidence", 0.0),
                "ml_prob": round(ctx.get("ml_prob", 0.5) * 100, 1),
                "reason": groq_eval.get("reason", ""),
                "sl": groq_eval.get("stop_loss", default_sl),
                "tp1": groq_eval.get("tp1", default_tp1),
                "surge": ctx["volume_surge_ratio"],
                "pullback": round(ctx.get("pullback_from_high_pct", 0) * 100, 2) if cand_side == "LONG" else round(ctx.get("bounce_from_low_pct", 0) * 100, 2),
                "model": groq_eval.get("model", "unknown"),
                "finish_reason": groq_eval.get("finish_reason", "unknown"),
                "time": time.strftime("%H:%M:%S")
            }
            portfolio.add_evaluation(eval_entry)
            print(f"🤖 [GROQ JEV] {sym} ({cand_side}): {eval_entry['decision']} ({int(eval_entry['confidence']*100)}%) | {eval_entry['reason']}", flush=True)

            if approved:
                portfolio.funnel_stats["passed"] += 1

                # 1. Проверка дневного лимита Circuit Breaker (если включен)
                if getattr(config, "ENABLE_CIRCUIT_BREAKER", False) and portfolio.get_daily_loss() >= config.MAX_DAILY_LOSS_USD:
                    print(f"🛑 [CIRCUIT BREAKER] Дневной лимит убытка (-${portfolio.get_daily_loss():.2f}) исчерпан. Защита депозита активна.", flush=True)
                    continue

                entry_p = ctx["current_price"]
                wick_sl = eval_entry["sl"]

                # Минимальное расстояние тейк-профитов для защиты от микро-сделок:
                # TP1: минимум 1.5% хода цены (+90.0% ROI при 60x)
                # TP2: минимум 3.0% хода цены (+180.0% ROI при 60x)
                min_tp1_dist = entry_p * config.TP1_PCT
                min_tp2_dist = entry_p * config.TP2_PCT

                if cand_side == "LONG":
                    risk_per_coin = max(entry_p - wick_sl, entry_p * 0.002)
                    tp1_2r = round(max(entry_p + (config.TARGET_1_R * risk_per_coin), entry_p + min_tp1_dist), 6)
                    tp2_3r = round(max(entry_p + (config.TARGET_2_R * risk_per_coin), entry_p + min_tp2_dist), 6)
                else:  # SHORT
                    risk_per_coin = max(wick_sl - entry_p, entry_p * 0.002)
                    tp1_2r = round(min(entry_p - (config.TARGET_1_R * risk_per_coin), entry_p - min_tp1_dist), 6)
                    tp2_3r = round(min(entry_p - (config.TARGET_2_R * risk_per_coin), entry_p - min_tp2_dist), 6)

                risk_pct = risk_per_coin / entry_p

                # 2. ИНСТИТУЦИОНАЛЬНЫЙ РАСЧЕТ РАЗМЕРА ОТ СТОП-ЛОССА (TRUE RISK-BASED SIZING):
                # Маржа подбирается математически так, чтобы при срабатывании стопа терялась ровно сумма risk_usd (10% от депо)
                lev_to_use = getattr(portfolio, "current_leverage", config.LEVERAGE)
                risk_pct = getattr(config, "COMPOUND_RISK_PCT", 0.10) if config.ENABLE_COMPOUNDING else 0.10
                risk_usd = max(portfolio.cash * risk_pct, config.MAX_RISK_PER_TRADE_USD)

                # Реальное расстояние до стопа (не менее 0.3% для безопасности)
                stop_dist_pct = max(risk_per_coin / entry_p, 0.003)

                # Формула: margin = risk_usd / (stop_dist_pct * leverage)
                calc_margin = risk_usd / (stop_dist_pct * lev_to_use)

                # Потолок: не более 45% от баланса портфеля и не менее $3.00 (минимальный лот биржи)
                actual_margin = round(min(max(calc_margin, 3.0), portfolio.cash * 0.45), 2)

                # Проверка лимитов портфеля и открытие позиции
                if len(portfolio.open_positions) < config.MAX_CONCURRENT_POSITIONS and portfolio.cash >= actual_margin:
                    portfolio.open_position(
                        symbol=sym,
                        side=cand_side,
                        entry_price=entry_p,
                        size_usdt=actual_margin,
                        wick_sl=wick_sl,
                        tp1=tp1_2r,
                        tp2=tp2_3r,
                        groq_reason=f"2R/3R Target | {eval_entry['reason']}",
                        leverage=lev_to_use
                    )
            else:
                if groq_eval.get("decision") == "SKIP":
                    portfolio.funnel_stats["groq_skip"] = portfolio.funnel_stats.get("groq_skip", 0) + 1
                elif groq_eval.get("confidence", 0.0) < config.GROQ_MIN_CONFIDENCE:
                    portfolio.funnel_stats["low_conf"] = portfolio.funnel_stats.get("low_conf", 0) + 1

                # Сохраняем в Shadow Tracker для анализа отклонённых сетапов
                portfolio.shadow_trades.insert(0, {
                    "symbol": sym,
                    "side": cand_side,
                    "rejected_at_price": ctx["current_price"],
                    "current_price": ctx["current_price"],
                    "price_change_pct": 0.0,
                    "outcome": "Ожидание хода...",
                    "reason": eval_entry["reason"],
                    "time": time.strftime("%H:%M:%S"),
                    "timestamp": time.time(),
                    "score": eval_entry["confidence"]
                })
                if len(portfolio.shadow_trades) > 50:
                    portfolio.shadow_trades = portfolio.shadow_trades[:50]
                portfolio.save()

                try:
                    obsidian_vault.log_shadow_decision(eval_entry)
                except Exception:
                    pass

        return candidates_passed_hard

    async def run_loop(self):
        self.is_running = True
        print(f"📡 [MarketScanner] Автономный сканер запущен (Интервал: {config.SCAN_INTERVAL_SECONDS}с, LONG+SHORT)...", flush=True)
        while self.is_running:
            try:
                await self.scan_market_once()
            except Exception as e:
                print(f"⚠️ Ошибка в MarketScanner: {e}", flush=True)
            await asyncio.sleep(config.SCAN_INTERVAL_SECONDS)

market_scanner = MarketScanner()
