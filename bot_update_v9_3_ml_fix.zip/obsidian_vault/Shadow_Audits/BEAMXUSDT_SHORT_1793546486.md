---
date: 2026-11-01 17:21
symbol: BEAMXUSDT
side: SHORT
price_at_rejection: 0.004662
decision: SKIP
outcome: В процессе проверки
tags: [shadow, rejected, beamxusdt]
---
# 🛡️ Аудит отсева: BEAMXUSDT (SHORT)

- **Цена на момент отсева:** `$0.004662`
- **Причина отклонения ИИ:**  
> "RSI14 at 13.6 is well below the 25 threshold, indicating oversold conditions; despite strong volume and low lower wick, the trade is rejected."

- **Фактический исход на рынке:**  
> **В процессе проверки**
