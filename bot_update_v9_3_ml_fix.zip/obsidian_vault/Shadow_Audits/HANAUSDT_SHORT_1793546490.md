---
date: 2026-11-01 17:21
symbol: HANAUSDT
side: SHORT
price_at_rejection: 0.0154
decision: SKIP
outcome: В процессе проверки
tags: [shadow, rejected, hanausdt]
---
# 🛡️ Аудит отсева: HANAUSDT (SHORT)

- **Цена на момент отсева:** `$0.0154`
- **Причина отклонения ИИ:**  
> "Volume surge (1.42x) confirms breakdown conviction with low lower wick (15.4%) indicating no buyer support, and RSI (29.8) is not oversold."

- **Фактический исход на рынке:**  
> **В процессе проверки**
